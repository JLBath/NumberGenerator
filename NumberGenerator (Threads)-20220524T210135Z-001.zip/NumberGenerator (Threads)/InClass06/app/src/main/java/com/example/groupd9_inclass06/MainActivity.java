package com.example.groupd9_inclass06;
//GroupD9_InClass06
//Jacob Mack
//Jenna Bath

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private final String TAG = "demo";


    ExecutorService threadPool; //create a threadpool
    Handler threadMessageHandler;
    ProgressDialog progressDialog;

    ListView listViewGenerate;
    ArrayAdapter<String> adapter;
    TextView textViewTimes;
    Button btnGenerate;
    SeekBar seekBar;
    ProgressBar progressBar;
    TextView textViewProgress, textViewAverage, textViewAverageTxt, textViewGenerated;
    ArrayList<Double> numberList = new ArrayList<Double>();

    private int increment = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle(R.string.MainActivity);

//        progressDialog = new ProgressDialog(this);
//        progressDialog.setMessage("test update progress");
//        progressDialog.setMax(20);
//        progressDialog.setProgressStyle(progressDialog.STYLE_HORIZONTAL);
//        progressDialog.setCancelable(false);
//



        listViewGenerate = findViewById(R.id.listViewGenerate);
        seekBar = findViewById(R.id.seekBar);
        btnGenerate = findViewById(R.id.btnGenerate);
        textViewTimes = findViewById(R.id.textViewTimes);
        textViewAverageTxt = findViewById(R.id.textViewAverageTxt);
        progressBar = findViewById(R.id.progressBar);
        textViewProgress = findViewById(R.id.textViewProgress);
        textViewAverage = findViewById(R.id.textViewAverage);
        textViewGenerated = findViewById(R.id.textViewGenerated);

        threadPool = Executors.newFixedThreadPool(2); //2 is the amount of threads



        try {
            //progressBar.setProgress(increment);





            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                    textViewTimes.setText(String.valueOf(progress));
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                    Log.d(TAG, "onStartTrackingTouch: ");
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                    Log.d(TAG, "onStartTrackingTouch: ");
                }
            });

        } catch (Exception ex) {
            //Exception thrown from seekBar.
            Toast.makeText(MainActivity.this, R.string.ToastException, Toast.LENGTH_SHORT).show();

        }

        threadPool = Executors.newFixedThreadPool(2); //2 is number of threads

        btnGenerate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { //GENERATE
                progressBar.setVisibility(View.VISIBLE);
                textViewAverageTxt.setVisibility(View.VISIBLE);
                textViewAverage.setVisibility(View.VISIBLE);
                textViewProgress.setVisibility(View.VISIBLE);
                new Thread(new NumberGenerator(seekBar.getProgress())).start();
                progressBar.setMax(seekBar.getProgress());
                textViewProgress.setText("");
                textViewAverage.setText("");
                increment = 0;
                numberList.clear();
            }
        });

        threadMessageHandler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message msg) {
                switch (msg.what) {
                    case NumberGenerator.STATUS_START:
                        progressBar.setProgress(0);
                        btnGenerate.setClickable(false);

//                        progressBar.show();
                        break;
                    case NumberGenerator.STATUS_PROGRESS:
                        increment++;
                        progressBar.setProgress(increment);
                        adapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, android.R.id.text1, numberList );
                        listViewGenerate.setAdapter(adapter);
                        textViewProgress.setText(String.valueOf(increment) + "/"+ seekBar.getProgress());

                        Double average = 0.0;
                        for(int i = 0; i < numberList.size(); i++){
                            average = average + numberList.get(i);
                        }
                        average = average/increment;
                        textViewAverage.setText(String.valueOf(average));

                        break;
                    case NumberGenerator.STATUS_STOP:
                        btnGenerate.setClickable(true);

                        break;
                }
                return false;
            }
        });


    } //end of onCreate



    class NumberGenerator implements Runnable {
        static final int STATUS_START = 0x00;
        static final int STATUS_PROGRESS = 0x01;
        static final int STATUS_STOP = 0x02;
        static final String PROGRESS_KEY = "PROGRESS";

        private int size;

        NumberGenerator(int size) {
            this.size = size;
        }

        @Override
        public void run() {
            Message startMessage = new Message();
            startMessage.what = STATUS_START;
            threadMessageHandler.sendMessage(startMessage);

            for (int i = 0; i < size ; i++) {
                double value = HeavyWork.getNumber();
                numberList.add(value);
                Message progressMessage = new Message();
                progressMessage.what = STATUS_PROGRESS;
                progressMessage.obj = value;
                threadMessageHandler.sendMessage(progressMessage);

            }

            Message stopMessage = new Message();
            stopMessage.what = STATUS_STOP;
            threadMessageHandler.sendMessage(stopMessage);


        }
    } //end of NumberGenerator
} //end of activity